Navnkonvensjoner
----------------
Globale variabler: Stor forbokstav, ord deles med stor bokstav
Lokale variabler: Liten forbokstav, ord deles med stor bokstav
Konstanter: Bare store bokstaver
Konstanter i samme type: Skilles ved å bruke understrek for ulik funksjon (eks. MD_Stop, MD_Down)

